package com.teja.backend.model;

import java.util.List;


import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table
@Component
public class Category {
	@Id
	private String id;
	private String name;
	private String description;
	private String label;

	/*@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "mcat_Id", insertable = false, updatable = false)
	private MainCategory mcategory;

	public MainCategory getMcategory() {
		return mcategory;
	}

	public void setMcategory(MainCategory mcategory) {
		this.mcategory = mcategory;
	}

	private String mcat_Id;

	public String getMcat_Id() {
		return mcat_Id;
	}

	public void setMcat_Id(String mcat_Id) {
		this.mcat_Id = mcat_Id;
	}
*/

	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

}
